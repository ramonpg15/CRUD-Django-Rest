from setuptools import setup

setup(name='testing',
      version='1.0',
      description='Tox en Django',
      author='Ramon Perez',
      author_email='ramonxdperez@hotmail.com',
      url='ramonpg15@github',
      packages=["escuela"],

      )