from django.apps import AppConfig


class Escuelav1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'escuelav1'
